export type AmplifyDependentResourcesAttributes = {
    "api": {
        "lwdashboard": {
            "GraphQLAPIKeyOutput": "string",
            "GraphQLAPIIdOutput": "string",
            "GraphQLAPIEndpointOutput": "string"
        }
    }
}